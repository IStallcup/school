Isaac Stallcup
Welcome to my smallsh!

simply run the command 'make' with the files 'makefile'
and 'main.c' in the pwd. Alternatively, run
'gcc main.c -o smallsh' to compile.
