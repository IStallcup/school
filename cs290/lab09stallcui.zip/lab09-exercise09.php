<html lang="en">
<head>

<!-- Latest compiled and minified Bootstrap Core CSS -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<!-- Bootstrap theme -->
<link href="../../dist/css/bootstrap-theme.min.css" rel="stylesheet">

   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
   <title>Exercise 9-9</title>
</head>
<body>

<header>
<h1>File access in PHP</h1>
</header>

<div class='container'>
<?php 
//start by echoing the data in the file
	$fileContents = file_get_contents("datafile.txt");

	//get the data for each individual day
	$forecasts = explode("\n",$fileContents);
	unset($forecasts[14]); //explode creates empty element at idx 14

	//function inputs: day's forecast in format [month, day, year, high, low]
	//outputs requested format for temp, high, low
	function outputForecast($day)
	{
		$elements = explode(",",$day); //seperate the day's values by ,
		//create custom date to output
		$custom_date = mktime(0,0,0,$elements[0],$elements[1],$elements[2]);
		//formatting
        echo '<div class="panel panel-default col-lg-3 col-md-3 col-sm-6">';
		echo '<div class="panel-heading">';
		//output formatted date as title
		echo '<h3 class="panel-title">' . date("d M, Y",$custom_date) . '</h3>';
        echo '</div>';
        echo '<div class="panel-body">';
        echo '<table class="table table-hover">';
		//high/low temps
		echo '<tr><td>High:</td><td>' . $elements[3] . '</td></tr>';
        echo '<tr><td>Low:</td><td>' . $elements[4] . '</td></tr>';
        echo '</table>';
        echo '</div>';
        echo '</div>';
	}

	foreach($forecasts as $day) //output each day's forecast
		outputForecast($day);
?>
</div>


</body>
</html>
