<?php
echo '<footer>';
echo '&copy; 2016 Isaac Stallcup';
echo '</footer>';
?>
