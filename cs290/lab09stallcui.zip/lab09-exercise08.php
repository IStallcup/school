<html lang="en">
<head>

<!-- Latest compiled and minified Bootstrap Core CSS -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<!-- Bootstrap theme -->
<link href="../../dist/css/bootstrap-theme.min.css" rel="stylesheet">

   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
   <title>Exercise 9-7 | Processing file uploads</title>
</head>
<body>

<?php
function getFileUploadForm(){
return '<form enctype="multipart/form-data" method="post">

 <div class="form-group">
   <label for="file1">Upload a file</label>
   <input type="file" name="file1[]" id="file1" multiple/>
   <p class="help-block" id="errordiv">Browse for a file and post it to the server.</p>
</div>
<input type="submit" />
</form>';
}

function moveFile($fileToMove, $destination)
{
	echo $destination . '; Uploaded file successfully<br/>';
	move_uploaded_file($fileToMove, "UPLOADS/" . $destination)
		or die("error");
}
?>

<header>
<h1>Using $_FILES and $_POST</h1>
</header>

<div class='container'>
<?php 
//For starters we simply output the form everytime.
	$fileToMove = $_FILES['file1']['tmp_name'];
	$destination = "./UPLOADS/" . $_FILES["file1"]["name"];
	if ($_SERVER["REQUEST_METHOD"] == "POST")
	{
		if (is_array($_FILES["file1"]["error"]))
		{
			$count = 0;
			foreach($_FILES["file1"]["error"] as $error)
			{
				if ($error == UPLOAD_ERR_OK)
				{
					$clientName = $_FILES["file1"]["name"][$count];
					$serverName = $_FILES["file1"]["tmp_name"][$count];
					moveFile($serverName, $clientName);
					$count++;
				}	

			}
		}
		else
		{
			if ($_FILES["file1"]["error"] == UPLOAD_ERR_OK)
			{
				$clientName = $_FILES["file1"]["name"];
				$serverName = $_FILES["file1"]["tmp_name"];
				moveFile($serverName, $clientName);
			}
		}
	}
	else
		echo getFileUploadForm();
?>
</div>


</body>
</html>
