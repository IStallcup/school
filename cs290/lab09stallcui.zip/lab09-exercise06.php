<html lang="en">
<head>

<!-- Latest compiled and minified Bootstrap Core CSS -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<!-- Bootstrap theme -->
<link href="../../dist/css/bootstrap-theme.min.css" rel="stylesheet">

   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
   <title>Exercise 9-6 | Using the $_SERVER Array</title>
</head>
<body>
<header>
<h1>Demonstrating $_SERVER usage</h1>
</header>

<pre>
<?php
	echo "<h1>Server Side Values</h1>";
	echo "SERVER_NAME: " . $_SERVER["SERVER_NAME"] . "<br/>";
	echo "SERVER_SOFTWARE: " . $_SERVER["SERVER_SOFTWARE"] . "<br/>";
	echo "SERVER_ADDR: " . $_SERVER["SERVER_ADDR"] . "<br/>";

	echo "<h1>Headers from the client</h1>";
	echo "REMOTE_ADDR: " . $_SERVER["REMOTE_ADDR"] . "<br/>";
	echo "HTTP_USER_AGENT: " . $_SERVER["HTTP_USER_AGENT"] . "</br>";
	echo "HTTP_REFERER: " . $_SERVER['HTTP_REFERER'] . "<br/>";
?>
</pre>
</body>
</html>
