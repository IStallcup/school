<?php include 'sesh.php';?>
<?php

if (!isset($_SESSION["username"]))
	echo "\nUser not logged in.";
else {
include 'connectvars.php';
$CONNECTION = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
if (!$CONNECTION)
	die('Could not connect: ' . mysql_error());

echo 'recieved user: ' . $_POST["username"] . "\n";
echo 'recieved cwins: ' . $_POST["cwins"] . "\n";
echo 'recieved pwins: ' . $_POST["pwins"] . "\n";

$sql_query_set_scores = "UPDATE Scores SET wins='" . $_POST["pwins"] ."', loses='" . $_POST["cwins"] . "' WHERE username='" . $_POST["username"] . "' AND game='rps'";

echo 'SQL query: ' . $sql_query_set_scores . "\n";

$result = mysqli_query($CONNECTION, $sql_query_set_scores);
if (!$result)
	echo 'Error in setting wins/loses.';
}
?>
