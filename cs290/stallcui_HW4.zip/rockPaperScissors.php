<!DOCTYPE HTML>
<html lang="en">
<?php include 'header.php';?>
<body>
<?php include 'nav.php';?>
	<h1>
		Rock, Paper, Scissors
	</h1>

	<div id="container">

	<h2>Your wager:</h2>
	<input id="wager" type="number"/>
	<br>

	<!-- images instead of buttons? -->
	<div id="points"></div> <!-- display # points -->
	<h2>Choose one:</h2>
	<br>
	<input id="rockbutton" type="image" src="rock.jpg" alt="rock"/>
	<input id="paperbutton" type="image" src="paper2.jpg" alt="paper"/>
	<input id="scissorsbutton" type="image" src="scissors.png" alt="scissors"/>
	<div id="error"></div> <!-- error messages go here -->
	<div id="wins"></div> <!-- number of wins for each player -->
	<div id="images">
		<table id="imgtable">
			<tr>
				<th>
					Your choice:
				</th>
				<th>
					Comp choice:
				</th>
			</tr>
			<tr>
				<td id="yourImg">
				</td>
				<td id="compImg">
				</td>
			</tr>
		</table>
	</div>
	<div id="results"></div>

	</div> <!-- close to container div -->

	<?php include 'footer.php'; ?>

</body>
</html>
