<?php
	define('DB_HOST', 'oniddb.cws.oregonstate.edu');
	define('DB_USER', 'stallcui-db');
	define('DB_PASSWORD', 'XA2IBuP51S3BUUEk');
	define('DB_NAME', 'stallcui-db');
?>
