document.write("this text was written from JS");
