<html lang="en">
<head>

<!-- Latest compiled and minified Bootstrap Core CSS -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<!-- Bootstrap theme -->
<link href="../../dist/css/bootstrap-theme.min.css" rel="stylesheet">

   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
   <title>Exercise 9-1 Weather Forecast</title>
</head>

<body>
<header>
</header>

<?php 
	$days = array("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday");
	$forecast = array(	"Monday" => 	array(20, 10, "Cloudy"),
						"Tuesday" => 	array(30, 11, "Sunny"),
						"Wednesday" => 	array(26, 15, "Sunny"),
						"Thursday" => 	array(30, 18, "Cloudy"),
						"Friday" => 	array(30, 20, "Rain"),
						"Saturday" => 	array(29, 13, "Rain"),
						"Sunday" => 	array(25, 11, "Cloudy")
					);

	function outputForecast($day, $high, $low, $description)
	{
		echo '<div class="panel panel-default col-lg-3 col-md-3 col-sm-6">';
		echo '<div class="panel-heading">';
		echo '<h3 class="panel-title">' . $day . '</h3>';
		echo '</div>';
		echo '<div class="panel-body">';
		echo '<table class="table table-hover">';
		echo '<tr><td>High:</td><td>' . $high . '</td></tr>';
		echo '<tr><td>Low:</td><td>' . $low . '</td></tr>';
		echo '</table>';
		echo '</div>';
		echo '<div class="panel-footer"><img src="' . $description . '.png" /> ' . $description . '</div>';
		echo '</div>';
	
	}
?>

 <div class="container theme-showcase" role="main">  
	 <div class="jumbotron">
        <h1>Weather Forecast!</h1>
	<p>Coming soon...</p>
      </div>
       <div class="panel panel-default">
            <div class="panel-body">
				<?php 
					foreach ($forecast as $key => $weather)
					{
						outputForecast($key, $weather[0], $weather[1], $weather[2]);
					}	
				?> 
            </div>
       </div>
 </div>
</body>
</html>
