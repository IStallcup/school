<?php

phpinfo();
?>
