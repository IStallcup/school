#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define DEBUG 0

//code for cs371 winter 2018 project 1
//isaac stallcup ONID:stallcui

//c socket programming guide used courtesy of http://www.csd.uoc.gr/~hy556/material/tutorials/cs556-3rd-tutorial.pdf


//this function concatenates the user's handle with their message
char* createMsg(char* handle, char* msg)
{
    char tmpBuf[500] = "";
	strcat(tmpBuf,handle);
    strcat(tmpBuf,msg);
    //printf("msg: %s\n",tmpBuf);
    return tmpBuf;
}

int main(int argc, char* argv[])
{
	int sock;
	int port_no;
	const char * ip_addr;
	int close_status;
    int addr_set_result;
	int conn_status;
	struct sockaddr_in sock_addy;
    char recvBuf[500];
    char handle[11];
	char sendBuf[500];
    char* msg;
	int is_closed;
    
	//gets the user's handle
    printf("please input handle\n");
    scanf("%s",recvBuf);
    strcpy(handle,recvBuf);
	strcat(handle,">");
    printf("%s\n",handle);
    
    

	//port number is second command line argument from user
	port_no = atoi(argv[2]);
	//check port # is valid
	if ((int)(port_no) > 65535 || (int)(port_no) < 0)
	{
		printf("port # is invalid, value is %d\n", port_no);
		return -1;
	}

	//get IP addy as 1st argument
	ip_addr = argv[1];

	//try to create socket
	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock == -1)
	{
		printf("Error in creating socket\n");
		return -1;
	}

	sock_addy.sin_family = AF_INET;
	//htons sets port_no to the correct format
	sock_addy.sin_port = htons(port_no);
	//set the IP address into appropriate format
    addr_set_result = inet_pton(AF_INET, ip_addr, &sock_addy.sin_addr);
    //printf("%d\n",sock_addy.sin_addr.s_addr);
    if (addr_set_result != 1)
    {
        printf("IP address conversion failed\n");
        return -1;
    }
	

	//try to connect!
	conn_status = connect(sock,(struct sockaddr*)&sock_addy,sizeof(sock_addy));
	if (conn_status != 0)
	{
		printf("Connection failed :(\n");
		return -1;
	}

	//communcaiton loop
	while(1)
	{
		//display handle
		printf("%s",handle);
		//clear the sending buffer
    	sendBuf[0] = '\0';
		//scan user input
		scanf("%s",recvBuf);
		//if user wants to quit, quit
		if(strcmp(recvBuf,"\\quit\0") == 0)
		{
			shutdown(sock,2);
			close_status = close(sock);
			return 0;
		}
		//format message into sendBuf
	    strcpy(sendBuf,createMsg(handle,recvBuf));
		//send contents of sendBuf
	    send(sock, sendBuf, strlen(sendBuf), 0);
		//recieve, and check if the server is closed
	    is_closed = recv(sock, recvBuf, 500, 0);
		if (is_closed == 0)
		{
			printf("host closed conn\n");
			return 0;
		}
	    printf("%s\n",recvBuf);
	}    
	close_status = close(sock);
	if (close_status == -1)
		printf("Error in closing socket\n");
	else
		printf("Socket closed successfully\n");
	return 0;
}
