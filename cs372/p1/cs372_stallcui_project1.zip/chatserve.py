import socket
import sys, getopt

#
#	code for CS371 winter 2018 project 1
#	isaac stallcup ONID:stallcui
#

#resources used: socket programming page of python manual https://docs.python.org/2/library/socket.html
#basic idea for looping came from https://pythonspot.com/python-network-sockets-programming-tutorial/

#sends a message
def sendMsg(conn, handle, msg):
	conn.send((dispHandle(handle) + msg).rstrip())

#prints the handle
def dispHandle(handle):
	return handle + "> "

ip_tcp = '127.0.0.1'	#the IP for this server
port_no = int(sys.argv[1]) #get 1st command line arg as port #, cast to int
buff_size = 500 		#maximum # characters in msg is 500
handle = "mario" #suggested handle is luigi for client ;)

#create the socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#bind the socket
sock.bind((ip_tcp, port_no))
while 1: #runs infinitely until the server recieves SIG_INT signal
	sock.listen(1)
	conn, addr = sock.accept()
	while 1: #bad idea but we'll roll with it for now
		#recieve from the socket
		data = conn.recv(buff_size)
		#if there is no data, break into outer infinite loop and begin listen again
		if not data: break
		print(data)
		msg = raw_input()
		if (msg == "\quit"):
			#then quit
			print("host recieved message for quitting")
			conn.close()
			sys.exit()
		#send desried message
		sendMsg(conn, handle, msg + "\n")
