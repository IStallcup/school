<?php
echo '<head>';
echo '<title>';
	if ($_GET['page'] == 'home' || !$_GET['page'])
	{
		echo 'Rock Paper Scissors';
		echo '</title>';
		echo '<link rel="stylesheet" href="rockPaperScissors.css" />';
		echo '<script type="text/javascript" src="./rockPaperScissors.js"></script>';
	}
	else if ($_GET['page'] == 'about')
	{
		echo 'About';
		echo '</title>';
		echo '<link rel="stylesheet" href="rockPaperScissors.css" />';
		echo '<link rel="stylesheet" href="aboutrps.css" />';
	}
	else if ($_GET['page'] == 'signup')
	{
		echo 'Sign Up';
		echo '</title>';
		echo '<link rel="stylesheet" href="rockPaperScissors.css" />';
		echo '<link rel="stylesheet" href="signup.css" />';
		echo '<script type="text/javascript" src="./signup.js"></script>';
	}
	else if ($_GET['page'] == 'login')
	{
		echo 'Log In';
		echo '</title>';
		echo '<link rel="stylesheet" href="rockPaperScissors.css" />';
		echo '<link rel="stylesheet" href="login.css" />';
		echo '<script type="text/javascript" src="./login.js"></script>';
	}
	echo '</head>';
	
?>
