<html>
<head>
<title>Exercise 8-7</title>
</head>
<body>
<h1>Making and using functions</h1>


<table border=1>
<tr>
  <th>milliliters</th><th>Cups</th><th>Ounces</th>
<?php
	function convertUnits($startVal, $startUnits, $endUnits)
	{
		if ($startUnits != "ml")
			return false; //error out if startunits != ml
		$mlToOz = 0.033814;
		$mlToCup = 0.00422675;
		if ($endUnits == "oz") //if oz wanted, return conversion
			return number_format(($startVal * $mlToOz),2,".",",");
		else if ($endUnits == "cups") //else if cups wanted, return conversion
			return number_format(($startVal * $mlToCup),2,".",",");
		else return false; //otherwise error out

	}


for($i=50;$i<=1000;$i+=50){
	echo "<tr>";
	echo "<td>$i</td>";
	echo "<td>" . convertUnits($i,"ml","cups") . "</td>";
	echo "<td>" . convertUnits($i,"ml","oz") . "</td>";
	echo "</tr>";
}
?>
</tr>
</table>


</body>
</html>
