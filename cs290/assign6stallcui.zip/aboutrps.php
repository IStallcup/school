<?php include 'sesh.php';?>
<!DOCTYPE HTML>
<html lang="en">
<?php include 'header.php';?>
<body>
<?php
	include 'nav.php';
?>
	<h1>
		About
	</h1>
	<div id="container">
	<p>
		From <a href="https://en.wikipedia.org/wiki/Rock-paper-scissors">wikipedia</a>, rock paper scissors is a game where two players simultaneously select either rock, paper or scissors. A player who selects paper loses to one who selects scissors but wins against someone who selects rock. A player who selects scissors loses to someone who selects rock but wins against someone who selects paper. A player who selects rock loses to someone who selects paper, but wins against someone who selects scissors.
	</p>

	<h2>
		About this Page
	</h2>
	<p>
		This page was created by Isaac Stallcup in July 2016 for CS290's assignment 3.
	</p>
	<h2>
		Languages and Techniques Used
	<h2>
	<ul id="techlist">
		<li>HTML
			<ul>
				<li>Extensive structuring of webpages</li>
				<li>Table layout</li>
				<li>Hyperlink architecture, both local and non-local</li>
				<li>Inclusion of Javascript, CSS files</li>
			</ul>
		</li>
		<li>CSS
			<ul>
				<li>Use of many class, id selectors</li>
				<li>Use of built-in selector modifications</li>
				<li>Visual design of website, including font choices, color schemes, etc.</li>
			</ul>
		</li>
		<li>PHP
			<ul>
				<li>Use of session variables to ensure user is logged in</li>
				<li>Comparing form input with database information</li>
				<li>Connecting to remote SQL ONID to preserve user data</li>
				<li>POST and GET transfer of game and login variables</li>
				<li>Modifying table to display information from SQL database</li>
				<li>Dynamic inclusion of CSS and Javascript files</li>
				<li>Dynamically highlighted navigation bar</li>
				<li>Retrieval of user data from SQL database</li>
				<li>Connect HTML with Javascript to play games</li>
				<li>Updating HTML with results of games as they are played</li>
				<li>Dynamic modification of page titles</li>
			</ul>
		</li>
		<li>Javascript
			<ul>
				<li>Using AJAX to modify page contents as games are played</li>
				<li>Using AJAX to modify database contents as games are played</li>
				<li>Reading variables from HTML DOM objects</li>
				<li>Modification of HTML DOM objects</li>
				<li>Dynamic CSS modification</li>
				<li>Interaction with DOM to play games of blackjack, rock paper scissors</li>
				<li>Regex validation of passwords</li>
				<li>Form input validation</li>
			</ul>
		</li>
	<ul>	
	</div> <!-- end of container div -->

	<?php include 'footer.php'; ?>

</body>
</html>
