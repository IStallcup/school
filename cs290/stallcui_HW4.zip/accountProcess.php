<?php
	include 'header.php';
	echo '<body>';
	include 'nav.php';
	echo '<h1>My Account</h1>';
	echo '<div id="container">';
	echo 'Welcome ' . $_POST["username"] . '</br>';
	//div etc. to split this up
	echo 'Email: ' . $_POST["email"] . '</br>';
	echo 'First Name: ' . $_POST["first"] . '</br>';
	echo 'Last Name: ' . $_POST["last"] . '</br>';
	echo 'Username: ' . $_POST["username"] . '</br>';
	echo 'Agreed to privacy policy: ';
	if (isset($_POST["privacy"]))
		echo 'Yes</br>';
	else echo 'No</br>';
	echo '</div>';
	echo '</body>';
?>
