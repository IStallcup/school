function Die(col)
{
	this.color = col;
	this.faces = [1, 2, 3, 4, 5, 6];
}

Die.prototype.randomRoll = function()
{
	var randNum = Math.floor((Math.random() * this.faces.length) + 1	);
	return this.faces[randNum-1];
};

var dice = Array(new Die("0000FF"), new Die("0000FF"), new Die("0000FF"), new Die("0000FF"), new Die("0000FF"));
for (var i = 0; i < 5; i++)
{
	console.log(dice[i].randomRoll() + " was rolled");
}
