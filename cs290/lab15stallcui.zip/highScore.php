<?php


//Really simple engine to store highscores (no validation) in a plain text file.

if(isset($_GET['username'])&&isset($_GET['score'])){
	//add the high score to the file.
	if($_GET['score']>0)
  		file_put_contents("highscores.txt",$_GET['username'].",,,".$_GET['score']."\n",FILE_APPEND);
}
	$rows = file("highscores.txt");
		    
	foreach($rows as $row){
		     $items = explode(",,,",$row);
		     $highscores[$items[0]]=trim($items[1]);    		    
	}
//	$highscores[$_GET['username']]=$_GET['score'];

	asort($highscores);
	$sorted = array_reverse($highscores);
	foreach($sorted as $nm =>$score){
		$finalArray [] = array("name"=>$nm,"score"=>$score);
	}
	echo json_encode($finalArray);



?>