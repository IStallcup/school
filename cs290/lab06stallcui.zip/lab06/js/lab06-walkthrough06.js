function isBlank(inputField)
{
	if (inputField.value=="")
		return true;
	return false;
}

function makeRed(inputDiv)
{
	inputDiv.style.backgroundColor = "#AA0000";
	inputDiv.parentNode.style.backgroundColor = "#AA0000";
	inputDiv.parentNode.style.color = "#FFFFFF";
}

window.onload = function()
{
	var mainForm = document.getElementById("mainForm");
	mainForm.onsubmit = function(e)
	{
		var email = document.getElementById("email");
		if (! isValidEmail(email.value))
		{
			e.preventDefault();
			makeRed(email);
		}
		
		
		
		
		
		var requiredInputs = document.querySelectorAll(".required");
		for (var i = 0; i < requiredInputs.length; i++)
		{
			if(isBlank(requiredInputs[i]))
			{
				e.preventDefault();
				makeRed(requiredInputs[i]);
			}
		}
	}
	
	function makeClean(inputDiv)
	{
		inputDiv.style.backgroundColor = "#EEEE00";
	}

	var requiredInputs = document.querySelectorAll(".required");
	for (var i = 0; i < requiredInputs.length; i++)
	{
		requiredInputs[i].onfocus = function()
		{
			makeClean(this);
		}
	}
	function isValidEmail(email)
	{
		var dotPos = email.lastIndexOf(".");
		var atPos =  email.lastIndexOf("@");
		if (dotPos + 2 >= email.length)
		{
			return false;
		}
		if (atPos < 1)
		{
			return false;
		}
		return true;
	}

}
