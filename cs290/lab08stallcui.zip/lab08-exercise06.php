<html>
<head>
<title>Exercise 8-6</title>
</head>
<body>
<h1>Simple Calendar using Loops</h1>

<table border=1>
<tr> 
	<th colspan = 7>
		<?php echo date("F");?>
	</th>
</tr>
<tr>
  <th>Sun</th><th>Mon</th><th>Tue</th><th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th>
</tr>

<?php 
	$day = 0;
	$dayOne = date("w",mktime(0,0,0,date("n"),1,date("Y")));
	$diff = $dayOne - $day; //amount of days offset from sunday for 1st day
	$i = 0; //counter var
	while ($i < $diff) //while counter < diff, print empty cell
	{
		echo "<td></td>";
		$i++;
	}
//	echo "diff = " . ($dayOne - $day);
	while ($i < date("t")+$diff) //lab has <=, but this produced 32 days in the month
	{
		// # days to go till is offset by diff, since we start at diff but still have to
		// have corect # days in the month
		
		if ($i % 7 == 0) //if counter is evenly divisible by 7, need a new week row
		{
			echo "</tr><tr>";
			echo "<td>" . ($day + 1) . "</td>"; //print day
		}
		else
			echo "<td>" . ($day + 1) . "</td>"; //otherwise just print day

		//iterate variables
		$day++;
		$i++;
	}
?>

</table>


</body>
</html>
