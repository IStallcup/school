
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>  
<script src = "underscore-min.js"></script>
<script src = "backbone-min.js"></script>

<body>

	  <form id="publishAlbums" method="post" action="publish.php">
            <h1>Publish Albums</h1>
            <ul id="albums">
                <!-- The albums will appear here -->
            </ul>
            <p id="totalAlbums">Publish: <span>0</span></p>
            <input type="submit" id="publish" value="Publish" />

        </form>

<script type="text/javascript">
    // Create a model for the albums
    var TravelAlbum = Backbone.Model.extend({
        defaults:{
            title: 'NewAlbum',
            photoCount: 0,
            puslished: false
        },

        // Fucntion to publish/unpublish
        toggle: function(){
            this.set('checked', !this.get('checked'));
        }
    });

    // Create a collection of albums
    var AlbumList = Backbone.Collection.extend({

        // Will hold objects of TravelAlbum
        model: TravelAlbum,

        // Return an array only with the published albums
        getChecked: function(){
            return this.where({checked:true});
        }
    });

 // Prefill the cpllection with some albums.
    var albums = new AlbumList([
        new TravelAlbum({ title: 'Banff, Canada', photoCount: 42}),
        new TravelAlbum({ title: 'Santorini, Greece', photoCount: 102}),    		  
    ]);

    
    // This view turns a TravelAlbum model into HTML. Will create LI elements.
    var TravelAlbumView = Backbone.View.extend({
        tagName: 'li',

        events:{
            'click': 'toggleService'
        },

        initialize: function(){
            // Set up event listeners attached to change
            this.listenTo(this.model, 'change', this.render);
        },

        render: function(){
            // Create the HTML
            this.$el.html('<input type="checkbox" value="1" name="' + this.model.get('title') + '" /> ' + this.model.get('title') + '<span> ' + this.model.get('photoCount') + ' images</span>');
            this.$('input').prop('checked', this.model.get('checked'));

            // Returning the object is a good practice
            // that makes chaining possible
            return this;
        },

        toggleService: function(){
            this.model.toggle();
        }
    });

    // The main view of the application
    var App = Backbone.View.extend({

        // Base the view on an existing element
        el: $('body'),

        initialize: function(){

            // Cache these selectors
            this.total = $('#totalAlbums span');
            this.list = $('#albums');

            // Listen for the change event on the collection.
            this.listenTo(albums, 'change', this.render);

            // Create views for every one of the albums in the collection
            albums.each(function(album){
                var view = new TravelAlbumView({ model: album });
                this.list.append(view.render().el);

            }, this);	// "this" is the context in the callback
        },

        render: function(){

            // Calculate the count of published albums.
            // the prices of only the checked elements
            var total = 0;
	    var photos = 0;

            _.each(albums.getChecked(), function(elem){
                total ++;
		photos+= elem.get("photoCount");
            });

            // Update the total price
            this.total.text(total+' Albums ('+photos+' images)');

            return this;
        }
    });

    new App();

</script>	