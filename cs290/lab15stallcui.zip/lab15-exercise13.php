<html lang="en">
<head>

<!-- Latest compiled and minified Bootstrap Core CSS -->
<link rel="stylesheet" href="bootstrap.min.css">
<link rel="stylesheet" href="die.css">

   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
   <title>Exercise 15-14 | FormData File Upload</title>
<script src="http://code.jquery.com/jquery-2.1.0.min.js"></script>
<script type="text/javascript">
window.jQuery ||
document.write('<script src="jquery-2.1.0.min.js"><\/script>');
</script>
<script src='lab15-exercise14.js'></script>
</head>
<body>

<header>
<h1>A Game of Dice</h1>
</header>


<div class="jumbotron">
<div class="container">
<div class="row">
  <div class="col-md-8"> <span id='rollCount'>Roll 1/3 </span><input type='button' value='Roll' id='rollButton'/></div>
  <div class="col-md-4">
    <div id='score'>Score: 0</div>
    <div id='turnCount'>Turns Left: 5</div>
</div>
</div>
<div class="row">
  <div class="col-md-8">
    <div class="playarea">
      <div class='die' id='die1'></div>
      <div class='die' id='die2'></div>
      <div class='die' id='die3'></div>
      <div class='die' id='die4'></div>
      <div class='die' id='die5'></div>
    </div>
  </div>
  <div class="col-md-4">
   <div class="desiredRolls">
     <h3> Desired Rolls</h3>
     <form action="">
     <div class="radio roll" id="3ofkind"><label><input type='radio' name='result' value='3ofkind' id='3ofkindcb' disabled/> 3 of a kind</label></div>
     <div class="radio roll" id="4ofkind"><label><input type='radio' name='result' value='4ofkind' id='4ofkindcb' disabled/> 4 of a kind</label></div>
     <div class="radio roll" id="5ofkind"><label><input type='radio' name='result' value='5ofkind' id='5ofkindcb' disabled/> 5 of a kind</label></div>
     <div class="radio roll" id="straight"><label><input type='radio' name='result' value='straight' id='straightcb' disabled /> straight</label></div>
     <input class='disabled' type='button' value='Make Choice' id='turnButton' disabled />
     </form>
  </div>
</div>
<div class="row">
    <div class="col-md-4" id='highscores'>      
    </div>
    <div class="col-md-4" id='userpanel'>      
      <?php 
	 session_start();
	 if ($_SESSION['username']!=""){
	   echo "<h3>Hi ".$_SESSION['username']."<h3>";
	   echo "<input type='hidden' id='session_username' value='".$_SESSION['username']."'>";
	 }
	 else{
	 echo '
	       <form id="loginform" action="processAvatar.php" method="post" enctype="multipart/form-data">
		 <h3>User Settings</h3>
		 <label><input type="text" id="username" name="username"/>Username:</label>
		 <label><input type="text" name="hometown"/>Hometown:</label>
		 <label><input type="file" id="avatar" name="avatar"/>Avatar:</label>
		 
		 <label><input type="submit" value="submit"/></label>
	       </form>';
	 }
	 ?>

    </div>
</div>

</div>
</div>

</body>
</html>
