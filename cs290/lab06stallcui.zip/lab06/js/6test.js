//var stringOne = new String("Test #1");
//document.write(stringOne);

//var dateOne = new Date();
//document.write(dateOne);

//document.write(Math.PI+"<br/>");
//document.write(Math.sqrt(4)+"<br/>");
//document.write(Math.random()+"<br/>");


function isBlank(inputField)
{
	if (inputField.value=="")
		return true;
	return false;
}

function isValidEmail(email)
{
	var dotPos = email.lastIndexOf(".");
	var atPos = email.lastIndexOf("@");
	if (dotPos + 2 >= email.length)
		return false;
	if (atPos < 1)
		return false;
	return true;
}

window.onload = function()
{
	var mainForm = document.getElementById("mainForm");
	mainForm.onsubmit = function(e)
	{
		
		var requiredInputs = document.querySelectorAll(".required");
		for (var i = 0; i < requiredInputs.length; i++)
		{
			var email = document.getElementById("email");
			if (!isValidEmail(email.value0))
			{
				e.preventDefault();
				email.style.backgroundColor = "#AA0000";
				email.parentNode.style.backgroundColor = "#AA0000";
				email.parentNode.style.color = "#FFFFFF";
			}
			if (isBlank(requiredInputs[i]))
			{
				e.preventDefault();
				requiredInputs[i].style.backgroundColor = "#AA0000";
				requiredInputs[i].parentNode.style.backgroundColor = "#AA0000";
				requiredInputs[i].parentNode.style.color = "#FFFFFF";
			}
			requiredInputs[i].onfocus = function()
			{
				this.style.backgroundColor = "#EEEE00";
			}
		}
	}
}
