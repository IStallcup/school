<!DOCTYPE HTML>
<html lang="en">
<?php include 'header.php';?>
<body>
<?php
	include 'nav.php';
?>
	<h1>
		About
	</h1>
	<div id="container">
	<p>
		From <a href="https://en.wikipedia.org/wiki/Rock-paper-scissors">wikipedia</a>, rock paper scissors is a game where two players simultaneously select either rock, paper or scissors. A player who selects paper loses to one who selects scissors but wins against someone who selects rock. A player who selects scissors loses to someone who selects rock but wins against someone who selects paper. A player who selects rock loses to someone who selects paper, but wins against someone who selects scissors.
	</p>

	<h2>
		About this Page
	</h2>
	<p>
		This page was created by Isaac Stallcup in July 2016 for CS290's assignment 3.
	</p>
	</div> <!-- end of container div -->

	<?php include 'footer.php'; ?>

</body>
</html>
