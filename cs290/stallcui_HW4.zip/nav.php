<nav>
	<ul>
		<?php
			echo '<li';
			if ($_GET['page'] == 'home' || !$_GET['page'])
				echo ' id="highlight">';
			else echo '>';
			echo '<a href="./rockPaperScissors.php?page=home';
			echo '&amp;login=';
			if ($_GET['login'] == 'false' || !$_GET['login'])
				echo 'false';
			else echo $_GET['login'];
			echo '">home</a></li>';

			echo '<li';
			if ($_GET['page'] == 'about')
				echo ' id="highlight">';
			else echo '>';
			echo '<a href="./aboutrps.php?page=about';
			echo '&amp;login=';
			if ($_GET['login'] == 'false' || !$_GET['login'])
				echo 'false';
			else echo $_GET['login'];
			echo '">about</a></li>';
				
			echo '<li';
			if ($_GET['page'] == 'signup')
				echo ' id="highlight">';
			else echo '>';
			echo '<a href="./signup.php?page=signup';
			echo '&amp;login=';
			if ($_GET['login'] == 'false' || !$_GET['login'])
				echo 'false';
			else echo $_GET['login'];
			echo '">signup</a></li>';

			echo '<li';
			if ($_GET['page'] == 'login')
				echo ' id="highlight">';
			else echo '>';
			echo '<a href="./login.php?page=login';
			echo '&amp;login=';
			if ($_GET['login'] == 'false' || !$_GET['login'])
				echo 'false';
			else echo $_GET['login'];
			echo '">login</a></li>';
		?>
	</ul>
</nav>

<?php 
	if ($_GET['login'] != 'false' && $_GET['login'])
	{
		echo '<h2>Welcome, ';
		echo $_GET['login'];
		echo '</h2>';
	}
?>
