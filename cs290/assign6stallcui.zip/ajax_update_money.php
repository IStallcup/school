<?php include 'sesh.php';?>
<?php

if (!isset($_SESSION["username"]))
{
	echo "\nUser not logged in.";
}
else {
include 'connectvars.php';
$CONNECTION = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
if (!$CONNECTION)
	die('Could not connect: ' . mysql_error());

echo 'recieved user: ' . $_POST["username"] . "\n";
echo 'recieved points: ' . $_POST["numPoints"] . "\n";

$sql_query_set_points = "UPDATE Scores SET score='" . $_POST["numPoints"] ."' WHERE username='" . $_POST["username"] . "' AND game='rps'";

echo 'SQL query: ' . $sql_query_set_points . "\n";

$result = mysqli_query($CONNECTION, $sql_query_set_points);
if (!$result)
	echo 'Error in setting points.';
}
?>
