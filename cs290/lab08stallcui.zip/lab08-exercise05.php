<html>
<head>
<title>Exercise 8-3</title>
</head>
<body>
<h1>Age calculator with Conditionals</h1>
<?php
	
	$birthday = mktime(0,0,0,5,31,1995);
	$today = time();
	$secondsOld = $today - $birthday;
	$daysOld = $secondsOld/(60*60*24);
	$monthsOld = $daysOld/30.4;
	$yearsOld = $monthsOld/12;

	$month = 5; //not sure if supposed to set these, but otherwise things get screwy
	$day = 31;

	$timeToNextBirthday = mktime(0,0,0,$month,$day,date("Y"));
	if ($timeToNextBirthday<$today)
	{
		//next birthday is next year.
		$timeToNextBirthday = mktime(0,0,0,$month,$day,date("Y")+1);
	}

	$timeToNext = $timeToNextBirthday - $today;
	$daysUntilBDay = number_format($timeToNext/(60*60*24));

	if ($daysUntilBDay < 1)
	{
		echo "<h2>Happy Birthday!</h2>";
	}
	else if ($daysUntilBDay < 7)
	{
		echo "Your Birthday is within a week!";
	}
	else if ($daysUntilBDay < 28)
	{
		echo "Your Birthday is within a month!";
	}
	else if ($daysUntilBDay < 182)
	{
		echo "Your Birthday is less than half a year away!";
	}
	else echo "Your birthday is a long ways away.";

	echo "<p>Time elapsed since " . date("M d, Y",$birthday) . ":</p>";
?>
<ul>
<li><?php echo $secondsOld; ?> seconds, or </li>
<li><?php echo number_format($daysOld); ?> days, or</li>
<li><?php echo number_format($monthsOld, 1, ".", ","); ?> months, or</li>
<li><?php echo number_format($yearsOld, 2, ".", ",");?> years</li>
</ul>
<?php echo "<p>Next Birthday in: " . $daysUntilBDay . " days"; ?>
</body>
</html>
