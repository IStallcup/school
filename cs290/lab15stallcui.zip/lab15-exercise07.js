function Die(col)
{
	this.color = col;
	this.faces = [1, 2, 3, 4, 5, 6];
	this.value = 0;
	this.locked = false;
}


Die.prototype.toggleLock = function()
{
	this.locked = !this.locked;
	colorDice();
}

Die.prototype.randomRoll = function()
{
	var randNum = Math.floor((Math.random() * this.faces.length) + 1	);
	this.value = this.faces[randNum - 1];
	return this.faces[randNum-1];
};

var dice = Array(new Die("0000FF"), new Die("0000FF"), new Die("0000FF"), new Die("0000FF"), new Die("0000FF"));
var rollNum = 1;
var turnNum = 1;

function colorDice()
{
	for (var i = 1; i <= 6; i++)
	{
		$("body div .die:contains('"+i+"')").css("background-color","rgb("+parseInt(i/6*255)+","+parseInt(i/6*255)+","+parseInt(i/6*255)+")");
		//console.log("rgb("+parseInt(i/6*255)+","+parseInt(i/6*255)+","+parseInt(i/6*255)+")");
		if (i <= 2)
			$("body div .die:contains('"+i+"')").css("color","white");
		else $("body div .die:contains('"+i+"')").css("color","black");
		if (i < 6)
		{
		//	console.log(i);
			var d = dice[i-1];
			if (d.locked == true)
				$("#die"+i).css("border","solid red 1px");
			else
				$("#die"+i).css("border","solid black 1px");
		}
	}
}

function isWinning(dice)
{
	//function checks for 3, 4, 5 of a kind and 5-die straight
	//returns array of options that are satisifed
	
	patternsMatched = Array();
	dice.sort(function(a,b){return a.value - b.value});
	for (var i = 0; i < dice.length; i++)
		console.log(dice[i].value + " ");

	var matches = 0;
	for (var i = 0; i < dice.length; i++)
	{
		if (i > 0)
		{
			if (dice[i].value == dice[i-1].value)
			{
				matches++;
				console.log("match found: " + matches + "x " + dice[i].value);
			}
			else matches = 1;
		}
		else matches = 1;
		if (matches >= 3)
			patternsMatched.push(matches+"ofkind");
	}

	for (var i = 1; i < dice.length; i++)
	{
		if (dice[i].value != dice[i-1].value+1)
			break;
		if (i == dice.length-1)
			patternsMatched.push("straight");
	}
		
	return patternsMatched;
}

function dieClicked() //toggle lock on appropriate die
{
	console.log("die clicked");
	for (var i = 0; i < dice.length; i++)
	{
		var checkMe = $("#die" + (i+1));
		console.log(checkMe.text());
		console.log($(this).text());
		if (checkMe.attr('id') == $(this).attr('id'))
			dice[i].toggleLock();
	}
	console.log("dice:");
	for (i = 0; i < dice.length; i++)
		console.log(dice[i]);
}

function RollUnlocked()
{
	
	for (i = 0; i < dice.length; i++)
		console.log(dice[i]);


	for (var i = 0; i < dice.length; i++)
	{
		if (!dice[i].locked)
		{
			var randomVal = dice[i].randomRoll();
			console.log(randomVal + " was rolled");
			var dieNode = $("#die" + (i+1));
			dieNode.html(randomVal);
		}
	}

	rollNum++;
	if (rollNum >= 3)
	{
		turnOver();
	}

	var moves = isWinning(dice);
	console.log(moves);
	$(":radio").attr("disabled");
	$(".roll").css("color","rgb(140,140,140)");

	for (var i = 0; i < moves.length; i++)
	{
		$("#"+moves[i]+"cb").removeAttr("disabled");
		$("#"+moves[i]).css("color","black");
	}

	for (i = 0; i < dice.length; i++)
		console.log(dice[i]);
	
	console.log("call colorDice");
	colorDice();
	$("#rollCount").html("Roll: " + rollNum + "/3");
	
	for (i = 0; i < dice.length; i++)
		console.log(dice[i]);
}

function turnOver()
{
	turnNum++;
	$("#rollButton").attr("disabled","true");
	$("#rollButton").attr("value","No more rolls this turn");	
}

$(document).ready(
	function()
	{
		console.log("jQuery is ready to use...");
		for (i = 0; i < dice.length; i++)
		{
			var randomVal = dice[i].randomRoll();
			console.log(randomVal + " was rolled");
			var dieNode = $("#die" + (i+1)); //jQuery selector
			dieNode.html(randomVal);
		}

		for (i = 0; i < dice.length; i++)
		{
			console.log(dice[i]);
		}


		colorDice();
		var moves = isWinning(dice);
		console.log(moves);
		
		for (var i = 0; i < moves.length; i++)
			$("#"+moves[i]+"cb").removeAttr("disabled");
		
		$(".die").on("click",dieClicked);
		$("#rollButton").on("click",RollUnlocked);
	}
);
