<?php

include 'sesh.php';
include 'header.php';
echo '<body>';
include 'nav.php';

echo '<h1>Logout</h1>';

echo '<div id="container">';

session_unset();

if (isset($_SESSION["username"]))
	echo 'Error logging you out.';
else echo 'You are now successfully logged out.';


echo '</div>';


include 'footer.php';
echo '</body>';
?>
