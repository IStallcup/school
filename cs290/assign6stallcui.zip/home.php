<?php include 'sesh.php';?>
<html>
<?php
	include 'header.php';
	echo '<body>';
	include 'nav.php';
	echo '<h1>Home</h1>';
	echo '<div id="container">';
	echo '<p>Welcome to my webpage! Games and other content are given above.<p>';
	echo '</div>';
	include 'footer.php';
	echo '</body>';
?>
</html>
