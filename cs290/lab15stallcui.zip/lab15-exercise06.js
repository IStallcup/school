function Die(col)
{
	this.color = col;
	this.faces = [1, 2, 3, 4, 5, 6];
	this.value = 0;
}

Die.prototype.randomRoll = function()
{
	var randNum = Math.floor((Math.random() * this.faces.length) + 1	);
	this.value = this.faces[randNum - 1];
	return this.faces[randNum-1];
};

var dice = Array(new Die("0000FF"), new Die("0000FF"), new Die("0000FF"), new Die("0000FF"), new Die("0000FF"));
/*for (var i = 0; i < dice.length; i++)
{
	console.log(dice[i].randomRoll() + " was rolled");
}*/

$("body div .die:contains('1')").css("background-color","#AA0000");

function colorDice()
{
	for (var i = 1; i <= 6; i++)
	{
		$("body div .die:contains('"+i+"')").css("background-color","rgb("+parseInt(i/6*255)+","+parseInt(i/6*255)+","+parseInt(i/6*255)+")");
		console.log("rgb("+parseInt(i/6*255)+","+parseInt(i/6*255)+","+parseInt(i/6*255)+")");
		if (i <= 2)
		{
			$("body div .die:contains('"+i+"')").css("color","white");
		}
	}
}

function isWinning(dice)
{
	//function checks for 3, 4, 5 of a kind and 5-die straight
	//returns array of options that are satisifed
	
	patternsMatched = Array();
	dice.sort(function(a,b){return a.value - b.value});
	for (var i = 0; i < dice.length; i++)
		console.log(dice[i].value + " ");

	var matches = 0;
	for (var i = 0; i < dice.length; i++)
	{
		if (i > 0)
		{
			if (dice[i].value == dice[i-1].value)
			{
				matches++;
				console.log("match found: " + matches + "x " + dice[i].value);
			}
			else matches = 1;
		}
		else matches = 1;
		if (matches >= 3)
			patternsMatched.push(matches+"ofkind");
	}

	for (var i = 1; i < dice.length; i++)
	{
		if (dice[i].value != dice[i-1].value+1)
			break;
		if (i == dice.length-1)
			patternsMatched.push("straight");
	}
		
	return patternsMatched;
}

$(document).ready(function()
		{
			console.log("jQuery is ready to use...");
			for (i = 0; i < dice.length; i++)
			{
				var randomVal = dice[i].randomRoll();
				console.log(randomVal + " was rolled");
				var dieNode = $("#die" + (i+1)); //jQuery selector
				dieNode.html(randomVal);
			}
			colorDice();
			var moves = isWinning(dice);
			console.log(moves);
			
			for (var i = 0; i < moves.length; i++)
				$("#"+moves[i]+"cb").removeAttr("disabled");
		}
		);
