var daysOfWeek = new Array("Monday","Tuesday","Wednesday","Thursday","Friday");
document.write(daysOfWeek+"<br/>");
daysOfWeek.push("Saturday");
document.write(daysOfWeek+"<br/>");
document.write("<table border=1><tr>");
for (var i = 0; i < daysOfWeek.length; i++)
{
	document.write("<th>"+daysOfWeek[i]+"</th>");
}
document.write("</tr>");
